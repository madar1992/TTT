package com.bitlabs;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SingleController extends HttpServlet {

	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		
		String path=req.getServletPath();
		System.out.println("This is get method "+path);
		
		if(path.equals("")) {
			RequestDispatcher rd=req.getRequestDispatcher("/index.html");
			rd.forward(req, res);
		}
		else if(path.equals("/ReqRegisterForm")) {
			RequestDispatcher rd=req.getRequestDispatcher("/Register.html");
			rd.forward(req, res);
		}
		else if(path.equals("/ReqDeleteForm")) {
			RequestDispatcher rd=req.getRequestDispatcher("/delete.html");
			rd.forward(req, res);
		}
		else if(path.equals("/ReqUpdateForm")) {
			RequestDispatcher rd=req.getRequestDispatcher("/update.html");
			rd.forward(req, res);
		}
		
		
	}
public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		
		String path=req.getServletPath();
		System.out.println("This is post method"+path);
		
		
		if(path.equals("/reqWelcomePage")) {
			RequestDispatcher rd=req.getRequestDispatcher("/welcome.html");
			rd.forward(req, res);
		}
		
		
		
	}
}
