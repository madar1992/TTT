package servlet_jsp;

public interface DaoInterface {

	public boolean Login(String username,String password);
	public boolean Register(String username,String password);
}
