package servlet_jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DaoImpl implements DaoInterface{
	Connection con;
	
	public DaoImpl(){
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/madar","root","root");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public boolean Login(String username, String password) {
		// TODO Auto-generated method stub
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from jspuser");
			
			while(rs.next()) {
				if(rs.getString(1).equals(username) && rs.getString(2).equals(password)) {
				return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	@Override
	public boolean Register(String username, String password) {
		// TODO Auto-generated method stub
		
		try {
			PreparedStatement pstmt=con.prepareStatement("insert into jspuser values(?,?)");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			int i=pstmt.executeUpdate();
			if(i!=0) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
