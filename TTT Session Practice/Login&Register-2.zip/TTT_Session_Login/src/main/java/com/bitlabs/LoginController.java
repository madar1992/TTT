package com.bitlabs;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpRequest;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class LoginController extends HttpServlet {

    public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
      
        PrintWriter out=res.getWriter();
         String uname=req.getParameter("uname");
         String pwd=req.getParameter("pwd");
         
         DaoImpl dao=new DaoImpl();
         
         
         boolean b=dao.validate(uname, pwd);
         
         if(b) {
               RequestDispatcher rd=req.getRequestDispatcher("/welcome.html");
               rd.forward(req, res);
                }
         else{
               RequestDispatcher rd=req.getRequestDispatcher("/index.html");
               rd.include(req, res);
               out.println("<body> Invalid username/password</body>");
               System.out.println("invalid username");
         }
    }
}